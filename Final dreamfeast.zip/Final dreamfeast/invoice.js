// This function will execute when the fully loaded
document.addEventListener('DOMContentLoaded', function() {
    //function that get data from localStorage
    function getLocalStorageItem(key) {
        return localStorage.getItem(key);
    }

    // Retrieve stored user data from localStorage
    const bookingDate = getLocalStorageItem('bookingDate');
    const totalNights = getLocalStorageItem('nights'); 
    const totalAmountDue = getLocalStorageItem('totalAmount'); 
    const invoiceDate = getLocalStorageItem('invoiceDate');
    const hotelName = getLocalStorageItem('hotelName');
    const selectedRoomType = getLocalStorageItem('roomType'); 
    const checkInDate = getLocalStorageItem('checkInDate');
    const guestFullName = getLocalStorageItem('guestName'); 
    const checkOutDate = getLocalStorageItem('checkOutDate');

    // Display the retrieved data in the corresponding elements
    document.getElementById('displayCheckOutDate').innerText = checkOutDate; // Show check-out date
    document.getElementById('displayNights').innerText = totalNights; // Show number of nights
    document.getElementById('displayBookingDate').innerText = bookingDate; // Show booking date
    document.getElementById('displayInvoiceDate').innerText = invoiceDate; // Show invoice date
    document.getElementById('displayGuestName').innerText = guestFullName; // Show guest name
    document.getElementById('displayHotelName').innerText = hotelName; // Show hotel name
    document.getElementById('displayRoomType').innerText = selectedRoomType; // Show room type
    document.getElementById('displayCheckInDate').innerText = checkInDate; // Show check-in date
    document.getElementById('displayTotalAmount').innerText = parseFloat(totalAmountDue).toFixed(2); // Show total amount decimal format

    // Add a click event listener to the checkout button
    document.getElementById('checkout-button').addEventListener('click', function() {
        // Redirect to the payment page when the button is clicked
        window.location.href = 'payment.html';
    });
});