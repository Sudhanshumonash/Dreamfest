document.getElementById('paymentForm').addEventListener('submit', function(event) {
    // Stop the form from submitting by default 
    event.preventDefault();

     //function to search for a form
    function getFieldValue(fieldId) {
        return document.getElementById(fieldId).value;
    }

    // all fields have to filled
    const nameOnCard = getFieldValue('cardName');
    const numberOnCard = getFieldValue('cardNumber');
    const expirationDate = getFieldValue('expiryDate');
    const securityCode = getFieldValue('cvv');
    const paymentAmount = getFieldValue('amount');

    // Validate that all fields have been filled
    if (nameOnCard && numberOnCard && expirationDate && securityCode && paymentAmount) {
        try {
            // Process the payment
            alert('Payment processed successfully!');
        } catch (error) {
            // Handle any errors that occur during the payment processing
            console.error('Error processing payment:', error);
            alert('An error occurred while processing your payment. Please try again.');
        }
    } else {
        // Notify the user to fill in all required fields
        alert('Please fill in all the fields.');
    }
});
document.getElementById('checkout-button').addEventListener('click', function() {
    window.location.href = 'index2.html';
});