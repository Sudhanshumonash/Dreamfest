
// these are some popular venues, link is directly link with hotel official website
document.addEventListener("DOMContentLoaded", function() {
    const moreInfoButtons = document.querySelectorAll(".button");

    moreInfoButtons.forEach(button => {
        button.addEventListener("click", function() {
            const hotelName = button.parentElement.querySelector("h3").textContent.trim();
            let websiteUrl = "";

            switch (hotelName) {
                // hotel maurya website link
                case "Hotel Maurya":
                    websiteUrl = "https://www.hotelmaurya.com/";
                    break;
                // Hotel Chinmaye Inn website link.
                case "Hotel Chinmaye Inn":
                    websiteUrl = "https://chinmaye.in/";
                    break;
                // Mahabodhi Resort websit link
                case "Mahabodhi Resort":
                    websiteUrl = "https://www.mahabodhihotel.com/";
                    break;
                // Bandhan Resort website link
                case "Bandhan Resort":
                    websiteUrl = "https://www.bandhanresort.in/";
                    break;
                default:
                    console.log("No website found for this hotel");
            }
            // this help to open website in new page
            if (websiteUrl !== "") {
                window.open(websiteUrl, "_blank");
            }
        });
    });
});


// these functions help to select hotels and the city, these function helps you to redirect to the selectded place and service.
function handleFormSubmit(event) {
event.preventDefault(); 

const serviceType = document.getElementById('serviceType').value;
const city = document.getElementById('city').value;

if 
// if service option selected to venues and city sselected to patna
(serviceType === 'venues' && city === 'Patna') {
    window.location.href = 'venues_patna.html';
} else if 
// if service option selected to venues and city sselected to bhagalpur
(serviceType === 'venues' && city === 'Bhagalpur') {
    window.location.href = 'venues_bhagalpur.html';
} else if 
// if service option selected to venues and city sselected to gaya
(serviceType === 'venues' && city === 'Gaya') {
    window.location.href = 'venues_gaya.html';
} else if 
// if service option selected to venues and city sselected to muzaffarpur
(serviceType === 'venues' && city === 'Muzaffarpur') {
    window.location.href = 'venues_muzaffarpur.html';
} else if 
// if service option selected to photography and city sselected to patna
(serviceType === 'photographers' && city === 'Patna') {
    window.location.href = 'photography_patna.html';
} else if 
// if service option selected to beautymakeup and city sselected to patna
(serviceType === 'beautyMakeup' && city === 'Patna') {
    window.location.href = 'makeup_patna.html';
} else if 
// if service option selected to planingdecor and city sselected to patna
(serviceType === 'planningDecor' && city === 'Patna') {
    window.location.href = 'decorators_patna.html';
} else if 
// if service option selected to music and city sselected to patna
(serviceType === 'musicDance' && city === 'Patna') {
    window.location.href = 'music_patna.html';
} else if 
// if service option selected to catering and city sselected to patna
(serviceType === 'catering' && city === 'Patna') {
    window.location.href = 'catering_patna.html';
// some of the pages are not avilable so (there is no service avilable) written.
} else {
    alert('There is No service avilable by Dreamfeast');
}
}

// these function are use for smooth scrolling between pages.
document.addEventListener("DOMContentLoaded", function() {
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();

    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });


    setTimeout(() => {
      window.scrollBy(0, -yourNavbarHeight); 
    }, 600); 
  });
});
});


// let verifynumber = 21;

// let usernumber = prompt("(Verify That You are Human)  Enter the number (hint- the number is only divisible by 3 and 7 and >30");

// while(verifynumber != usernumber){
//     usernumber = prompt("(Verify That You are Human) you entered wrong umber, enter again (hint - Enter the number (hint- the number is only divisible by 3 and 7 and >30)")
// }

// console.log("Congratulations you entered right number (You Are Verified)")