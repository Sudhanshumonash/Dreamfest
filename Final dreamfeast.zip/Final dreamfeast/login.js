
        function toggleEmailInput(action) {
            const emailInput = document.querySelector('input[name="email"]');
            if (action === 'signin') {
                emailInput.style.display = 'none';
            } else if (action === 'signup') {
                emailInput.style.display = 'block';
            }
        }
    