// Function to redirect to the booking page when any "Book Now" button is clicked
function redirectToBookingForm() {
    window.location.href = 'booking2.html';
  }
  // Wait until the document is fully loaded
  document.addEventListener('DOMContentLoaded', function() {
    // Select all elements with the class 'button'
    var buttons = document.querySelectorAll('.button');

    // Add a click event listener to each button
    buttons.forEach(function(button) {
        button.addEventListener('click', redirectToBookingForm);
    });
  });
  // Function to generate an invoice and store user data
  function generateInvoice() {
     // Get user input from the form field
    const bookingDate = document.getElementById('bookingDate').value;
    const invoiceDate = document.getElementById('invoiceDate').value;
    const hotelName = document.getElementById('hotelName').value;
    const checkInDate = document.getElementById('checkInDate').value;
    const guestName = document.getElementById('guestName').value;
    const totalAmount = document.getElementById('totalAmount').value;
    const roomType = document.getElementById('roomType').value;
    const checkOutDate = document.getElementById('checkOutDate').value;
    const nights = document.getElementById('nights').value;
  
    // Store user data in localStorage
    localStorage.setItem('checkInDate', checkInDate);
    localStorage.setItem('totalAmount', totalAmount);
    localStorage.setItem('bookingDate', bookingDate);
    localStorage.setItem('checkOutDate', checkOutDate);
    localStorage.setItem('nights', nights);
    localStorage.setItem('invoiceDate', invoiceDate);
    localStorage.setItem('guestName', guestName);
    localStorage.setItem('roomType', roomType);
    localStorage.setItem('hotelName', hotelName);
  
    // Open the invoice page in a new tab
    window.open('invoice.html', '_blank');
}
